                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2462340
M3 Hex Nut Height 2.4 by RobinHsu is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Customized version of http://www.thingiverse.com/thing:193647

Created with Customizer! http://www.thingiverse.com/apps/customizer/run?thing_id=193647



# Instructions

Using the following options:

non_thread_length = 0
resolution = 0.5
socket_facets = 6
drive_type = socket
head_diameter = 12
thickness = 2
wing_ratio = 1
nut_thread_outer_diameter = 3.1
slot_depth = 2
thread_step = 0.5
outer_diameter = 14
drive_diameter = 5
nut_diameter = 5
thread_length = 25
head_height = 5
socket_depth = 3.5
facets = 6
nut_type = normal
slot_width = 1
nut_height = 2.4
step_shape_degrees = 45
countersink = 2
non_thread_diameter = 0
nut_thread_step = 0.5
nut_step_shape_degrees = 45
thread_outer_diameter = 3.1
texture = exclude
inner_diameter = 8
type = nut
head_type = hex