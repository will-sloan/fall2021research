                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2090184
Seek Thermal Pro iPhone 7 Plus Mount  by sneaks is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

Recently I purchased a Seek CompactPro (Thermal Imager) and wasn't comfortable with the way the Camera mounted on the Lightning port.  Firstly, the device is costly and  I didn't want it to fall out or break off.  Secondly the mounting felt awkward during use.

This is a simple mount the encompasses the Seek CompactPro and snaps on the back of my iPhone 7 Plus with Tech 21 case.  Because I know most people aren't going to have my phone/case combo I included the Rhino File.  

<a href="http://a.co/fkZpwAC">Lightning Adapter I used</a>
<a href="http://a.co/bo8poEF">3mm Plastic Screws I used</a>

** I assume this will work for all of their versions (Compact & CompactXR) including the micro USB, however I have no way of confirming it.