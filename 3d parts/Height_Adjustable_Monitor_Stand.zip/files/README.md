# Height Adjustable Monitor Stand

Monitor stand requires just a breadboard (or other rigid plate), few wood screws (predrill holes) and printed parts.

Height can be adjusted by printing few or more tubes.

The construction is rigid enough usually, but if you need to incrase it, you can trace the legs on the cardbord, cut out the circles, put the feet through the holes and squeeze the cardbord between tubes and feet.

Thanks go to my brother for the design idea.

## Licensing

 * Where not specified otherwise, it is GNU GPL v3
 * Images are under CC BY-SA 3.0
